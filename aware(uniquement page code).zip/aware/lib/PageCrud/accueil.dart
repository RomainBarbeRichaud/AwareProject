// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart';

class Recherche extends StatefulWidget {
  @override
  State<Recherche> createState() => _RechercheState();
}

class _RechercheState extends State<Recherche> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  @override

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('Recherche'),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.search, color: Colors.white),
              onPressed: () {
                showSearch(
                  context: context,
                  delegate: CustomSearchDelegate(),);
              },
            ),
          ],
          elevation: 20,
          shadowColor: Colors.indigo,
        ),
      );
  }
}

Widget build(BuildContext context) {
  return Scaffold(
      body: SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.symmetric(vertical: 50.0, horizontal: 30.0),
         child: Form(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Image.asset('assets/images/logo.png', height : 400.0, width: 400.0),

           ]
          )
        )
      )
    )
  );
}




class CustomSearchDelegate extends SearchDelegate {
  List<String> searchTerms = [
    'Delirium',
    'Code Bar',
    'Groove Box karaoke',
    'La Mandragore',
    'Le Douanier',
  ];
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query =  '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context,null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<String> matchQuery = [];
    for (var bar in searchTerms) {
      if (bar.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(bar);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        return ListTile(
          title: Text(result),
        );
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> matchQuery = [];
    for (var bar in searchTerms) {
      if (bar.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(bar);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        return ListTile(
          title: Text(result),
        );
      },
    );
  }
}