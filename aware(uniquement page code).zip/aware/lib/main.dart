// ignore_for_file: prefer_const_constructors
import 'package:aware/PageCrud/accueil.dart';
import 'package:flutter/material.dart';
import 'PageCrud/profile_page.dart';



void main() => runApp(const MonApp());

class MonApp extends StatelessWidget {
  const MonApp({super.key});

  static const String _title = 'Flutter Code Sample';

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: _title,
      home: MyStatefulWidget(),
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({super.key});

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  static  List<Widget> _widgetOptions = <Widget>[    Recherche(),    ProfilePage(),    ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedFontSize: 20,
        selectedIconTheme: IconThemeData(color: Colors.black, size: 40),
        selectedItemColor: Colors.black,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
        iconSize: 50,
        backgroundColor: Colors.white,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.supervised_user_circle),
              label: 'Mon Profil'
          ),
        ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped
      ),
    );
  }
}
