import 'package:aware/model/user.dart';
// ignore_for_file: prefer_const_constructors

class UserPreferences {
  static const myUser = User(
    imagePath:
        'assets/images/test.jpg',
    name: 'Daft Punk',
    email: 'Daftpunk@gmail.com',
    about:
        'We are separated but it is ok.',
    contact: 'https://twitter.com/daftpunk',
    isDarkMode: false,
  );
}
