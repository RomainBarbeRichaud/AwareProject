// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart' ;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'connexion.dart';

class Inscription extends StatefulWidget {
  const Inscription({super.key});

  @override
  State<Inscription> createState() => _InscriptionState();
}

class _InscriptionState extends State<Inscription> {


  String nomGroupe = '';
  String genreMusical = '';
  int nbMembre = 0;
  String email = '';
  String motDePasse = '';
  String confirmMDP = '';

  final _formKey = GlobalKey<FormState>();
  @override

  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 50.0, horizontal: 30.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Image.asset('assets/images/logo.png', height : 200.0, width: 200.0),
                Center(
                  child: Text('Créer un compte Aware')
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Nom du Groupe',
                    border: OutlineInputBorder()
                  ),
                  validator: (value) => value!.isEmpty ? 'Entrer un nom' : null,
                  onChanged: (value) => nomGroupe= value,
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  decoration: const InputDecoration(
                      labelText: 'Genre Musical',
                      border: OutlineInputBorder()
                  ),
                  validator: (value) => value!.isEmpty ? 'Entrer un Genre' : null,
                  onChanged: (value) => genreMusical= value,
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Nombre de membre',
                      border: OutlineInputBorder()
                  ),
                  validator: (value) => value!.isEmpty ? 'Entrer un nombre' : null,
                  onChanged: (value) => nbMembre = value as int,
                ),
                SizedBox(height: 10.0),
                TextFormField(
                  decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder()
                  ),
                  validator: (value) => value!.isEmpty ? 'Entrer un email' : null,
                  onChanged: (value) => email = value,
                ),

                //Champ de saisie pour le mot de passe:
                SizedBox(height: 10.0),
                TextFormField(
                  decoration: const InputDecoration(
                      labelText: 'Mot de passe',
                      border: OutlineInputBorder()
                  ),
                  //indication de l'erreur de saisie:
                  validator: (value) => value!.length < 6 ? 'Entrer un mot de passe avec plus de 6 caractères' : null,
                  onChanged: (value) => motDePasse = value,
                  //Texte caché (car mdp)
                  obscureText: true,
                ),

                SizedBox(height: 10.0),
                TextFormField(
                  decoration: const InputDecoration(
                      labelText: 'Confirmer mot de passe',
                      border: OutlineInputBorder()
                  ),
                  obscureText: true,
                  onChanged: (value) => confirmMDP = value,
                  validator: (value) => confirmMDP != motDePasse ? 'Les mots de passe ne correspondent pas' : null,
                ),

                TextButton(
                  child: Text('Inscription'),
                  style: TextButton.styleFrom(
                    primary: Colors.white,
                    backgroundColor: Colors.teal,
                    onSurface: Colors.grey,
                  ),
                  onPressed: (){
                    if(_formKey.currentState!.validate()){
                    }
                  },
                ),
                OutlinedButton(
                  child: Text('Avez-vous déja un compte ?'),
                  style: TextButton.styleFrom(
                    primary: Colors.black,
                    backgroundColor: Colors.white,
                    onSurface: Colors.grey,
                    side: BorderSide(color: Colors.black,width: 1.5)
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Connexion()),
                    );
                  },
                )
              ],
            )
          )
        )
      )
    );
  }
}

