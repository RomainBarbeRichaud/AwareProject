import 'package:aware/PageAuth/inscription.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
// ignore_for_file: prefer_const_constructors

class Connexion extends StatefulWidget {
  const Connexion({super.key});


  @override
  State<Connexion> createState() => _ConnexionState();
}

class _ConnexionState extends State<Connexion> {

  String email = '';
  String password ='';

  final _keyForm = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            padding: EdgeInsets.symmetric(vertical: 50.0, horizontal: 30.0),
            child: Form(
                key: _keyForm,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Image.asset('assets/images/logo.png', height: 200.0, width: 200.0),
                      Center(
                          child: Text('Bienvenue sur Aware',)
                      ),
                      SizedBox(height: 10.0),
                      TextFormField(
                        decoration: const InputDecoration(
                            labelText: 'Email',
                            border: OutlineInputBorder()
                        ),
                        validator: (value) => value!.isEmpty ? 'Entrer un email' : null,
                        onChanged: (value) => email = value,
                      ),
                      SizedBox(height: 10.0),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: 'Password',
                          border: OutlineInputBorder(),
                        ),
                        obscureText:  true,
                        validator: (value) => value!.isEmpty ? 'Entrer un mot de passe' : null,
                        onChanged: (value) => password = value,
                      ),
                      SizedBox(height: 10.0),
                      TextButton(
                        onPressed: (){
                          if(_keyForm.currentState!.validate()){

                          }
                        },
                        child: Text('Connexion'),
                        style: TextButton.styleFrom(
                          primary: Colors.white,
                          backgroundColor: Colors.teal,
                          onSurface: Colors.grey,
                        ),
                      ),
                      OutlinedButton(
                        child: Text('Créer un compte'),
                        style: TextButton.styleFrom(
                            primary: Colors.black,
                            backgroundColor: Colors.white,
                            onSurface: Colors.grey,
                            side: BorderSide(color: Colors.black,width: 1.5)
                        ),
                        onPressed: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const Inscription()),
                          );
                        },
                      )
                    ]
                )
            )
        )
    );
  }
}